let str = '';
let option = document.querySelectorAll('#type li a'),
    navTab = document.getElementById('chooses');
option = Array.from(option);

option.forEach(item => {
    item.onclick = function () {
        let text = item.innerHTML;
        str += `<a href="javascript:;" id="aa">${text}</a>`;
        navTab.innerHTML = str;
    }
})

let des = document.querySelectorAll('#chooses #aa');

