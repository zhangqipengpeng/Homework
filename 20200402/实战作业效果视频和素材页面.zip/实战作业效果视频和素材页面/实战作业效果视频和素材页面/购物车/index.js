let lis = document.getElementsByTagName('li');
let ems = document.querySelectorAll('.info em')
console.log(lis)
for (let i = 0; i < lis.length; i++) {
    addClick(lis[i])
}
//给每个li绑定点击事件
function addClick(li) {
    let tags = li.getElementsByTagName('i');
    let em = li.getElementsByTagName('em')[0];
    let strongs = li.getElementsByTagName('strong');

    tags[0].onclick = function () {
        if (Number(em.innerHTML) <= 0) {
            em.innerHTML = 0;
        } else {
            em.innerHTML = Number(em.innerHTML) - 1;
            strongs[1].innerHTML = Number(em.innerHTML) * parseFloat(strongs[0].innerHTML) + '元';
            computed()
        }
    }
    tags[1].onclick = function () {
        em.innerHTML = Number(em.innerHTML) + 1;
        strongs[1].innerHTML = Number(em.innerHTML) * parseFloat(strongs[0].innerHTML) + '元';
        computed()
    }
}

function computed() {
    let total = 0;
    let allPrice = 0;
    let ary = [];
    for (let i = 0; i < lis.length; i++) {
        let em = lis[i].getElementsByTagName('em')[0];
        let strongs = lis[i].getElementsByTagName('strong');
        total += Number(em.innerHTML);
        allPrice += parseFloat(strongs[1].innerHTML);

        if (Number(em.innerHTML) >= 1) {
            ary.push(parseFloat(strongs[0].innerHTML))
            ary.sort((a, b) => {
                return b - a;
            })
        }
    }
    if (ary[0] == undefined) {
        ary[0] = 0;
    }
    ems[0].innerHTML = total;
    ems[1].innerHTML = allPrice;
    ems[2].innerHTML = ary[0];
}